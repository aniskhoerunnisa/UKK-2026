
<?php
include 'includes/cek_session.php';
include 'config/koneksi.php';

// Ambil data kategori pelanggaran
$sql = "SELECT * FROM t_kategori_pelanggaran ORDER BY nama_kategori ASC";
$query = mysqli_query($koneksi, $sql);

if (!$query) {
    die("Query gagal: " . mysqli_error($koneksi));
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Pelanggaran Kategori</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.8/css/dataTables.bootstrap4.min.css">

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f4f6ff;
            color: #202d49;
        }

        .sidebar {
            width: 280px;
            min-height: 100vh;
            background: #202d49;
            padding: 22px 15px;
            position: fixed;
            top: 0;
            left: 0;
            bottom: 0;
            overflow-y: auto;
        }

        .logo {
            color: white;
            font-size: 25px;
            font-weight: bold;
            margin-bottom: 38px;
        }

        .menu-label {
            color: #8390aa;
            font-size: 12px;
            margin-bottom: 18px;
        }

        .menu a {
            display: block;
            color: #e3e9f7;
            text-decoration: none;
            padding: 14px;
            margin-bottom: 7px;
            border-radius: 12px;
            font-size: 14px;
        }

        .menu a i {
            width: 25px;
        }

        .menu a:hover,
        .menu a.active {
            background: #5368ed;
            color: white;
        }

        .menu-divider {
            border-top: 1px solid #3b4760;
            margin-top: 20px;
            padding-top: 15px;
        }

        .logout {
            color: #ff5368 !important;
        }

        .main {
            margin-left: 280px;
            padding: 28px 30px 40px;
        }

        .page-title {
            font-size: 32px;
            font-weight: bold;
        }

        .page-title span {
            color: #7764ef;
        }

        .subtitle {
            color: #7e8ca9;
            margin-bottom: 25px;
        }

        .top-banner {
            background: linear-gradient(115deg, #5268ed, #8260e9);
            color: white;
            padding: 28px 32px;
            border-radius: 20px;
            margin-bottom: 25px;
            box-shadow: 0 10px 25px rgba(83,103,237,.12);
        }

        .top-banner .label {
            display: inline-block;
            background: rgba(255,255,255,.2);
            padding: 8px 14px;
            border-radius: 25px;
            font-size: 11px;
            margin-bottom: 12px;
        }

        .top-banner h3 {
            font-size: 25px;
            font-weight: bold;
        }

        .top-banner p {
            margin-bottom: 0;
            line-height: 1.8;
        }

        .btn-add {
            background: linear-gradient(110deg, #5268ed, #8260e9);
            color: white;
            border: none;
            border-radius: 10px;
            padding: 12px 18px;
            font-weight: bold;
        }

        .btn-add:hover {
            color: white;
            opacity: .9;
        }

        .table-card {
            background: white;
            padding: 24px;
            border-radius: 18px;
            box-shadow: 0 8px 25px rgba(30,45,80,.05);
        }

        .table-heading {
            font-size: 20px;
            font-weight: bold;
            margin-bottom: 6px;
        }

        .table-description {
            color: #7e8ca9;
            margin-bottom: 22px;
        }

        #tabelKategori {
            width: 100% !important;
        }

        #tabelKategori th,
        #tabelKategori td {
            vertical-align: middle;
        }

        #tabelKategori thead th {
            background: #202d49;
            color: white;
            border-color: #35425f;
            white-space: nowrap;
        }

        #tabelKategori td {
            color: #46536d;
        }

        .aksi {
            white-space: nowrap;
        }

        .btn-sm {
            border-radius: 7px;
            margin: 2px;
        }

        .dataTables_wrapper {
            color: #526078;
            font-size: 13px;
        }

        .dataTables_wrapper .page-item.active .page-link {
            background: #5368ed;
            border-color: #5368ed;
        }

        .dataTables_wrapper .page-link {
            color: #5368ed;
        }

        .footer {
            color: #8b97ad;
            font-size: 13px;
            margin-top: 25px;
        }

        @media (max-width: 767px) {
            .sidebar {
                position: relative;
                width: 100%;
                min-height: auto;
            }

            .main {
                margin-left: 0;
                padding: 22px 15px;
            }

            .page-title {
                font-size: 27px;
            }

            .table-card {
                padding: 15px;
            }
        }
    </style>
</head>

<body>

<!-- SIDEBAR -->
<aside class="sidebar">

    <div class="logo">
        <i class="fas fa-layer-group"></i> MyWebsite.
    </div>

    <div class="menu-label">MENU UTAMA</div>

    <nav class="menu">

        <a href="dashboard.php">
            <i class="fas fa-th-large"></i> Dashboard
        </a>

        <a href="kelola_siswa.php">
            <i class="fas fa-user-graduate"></i> Kelola Siswa
        </a>

        <a href="kelola_guru.php">
            <i class="fas fa-chalkboard-teacher"></i> Kelola Guru
        </a>

        <a href="kelola_wali_kelas.php">
            <i class="fas fa-user-tie"></i> Wali Kelas
        </a>

        <a href="kelola_kelas.php">
            <i class="fas fa-school"></i> Kelola Kelas
        </a>

        <a href="kelola_tahun_ajaran.php">
            <i class="fas fa-calendar-alt"></i> Tahun Ajaran
        </a>

        <a href="pelanggaran_kategori.php" class="active">
            <i class="fas fa-list-alt"></i> Pelanggaran Kategori
        </a>

        <a href="about_me.php">
            <i class="fas fa-user-circle"></i> About Me
        </a>

        <div class="menu-divider">
            <a href="logout.php" class="logout">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>

    </nav>
</aside>

<!-- KONTEN UTAMA -->
<main class="main">

    <h1 class="page-title">
        Pelanggaran Kategori <span>.</span>
    </h1>

    <p class="subtitle">
        Kelola kategori dan poin pelanggaran siswa ✨
    </p>

    <!-- BANNER -->
    <section class="top-banner">

        <div class="label">
            <i class="fas fa-exclamation-circle"></i>
            DATA PELANGGARAN
        </div>

        <h3>
            <i class="fas fa-list-alt"></i>
            Manajemen Kategori Pelanggaran
        </h3>

        <p>
            Lihat dan kelola berbagai kategori pelanggaran
            beserta poin yang berlaku bagi siswa.
        </p>

    </section>

    <!-- JUDUL DAN TOMBOL -->
    <div class="d-flex justify-content-between align-items-center flex-wrap mb-3">

        <div>
            <h4 class="font-weight-bold">Daftar Kategori Pelanggaran</h4>
            <p class="text-muted">
                Data kategori pelanggaran siswa.
            </p>
        </div>

        <a href="tambah_pelanggaran_kategori.php" class="btn btn-add mb-3">
            <i class="fas fa-plus"></i> Tambah Kategori
        </a>

    </div>

    <!-- TABEL -->
    <div class="table-card">

        <div class="table-heading">
            <i class="fas fa-list" style="color:#7764ef"></i>
            Tabel Kategori Pelanggaran
        </div>

        <p class="table-description">
            Cari kategori pelanggaran menggunakan kolom pencarian.
        </p>

        <div class="table-responsive">

            <table id="tabelKategori"
                   class="table table-bordered table-striped table-hover">

                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Nama Kategori</th>
                        <th>Deskripsi</th>
                        <th>Poin</th>
                        <th>Aksi</th>
                    </tr>
                </thead>

                <tbody>

                    <?php
                    $no = 1;

                    while ($row = mysqli_fetch_assoc($query)) {
                    ?>

                    <tr>

                        <td><?= $no++ ?></td>

                        <td>
                            <?= htmlspecialchars($row['nama_kategori']) ?>
                        </td>

                        <td>
                            <?= htmlspecialchars($row['deskripsi']) ?>
                        </td>

                        <td>
                            <span class="badge badge-danger">
                                <?= (int)$row['poin'] ?> Poin
                            </span>
                        </td>

                        <td class="aksi">

                            <a href="edit_pelanggaran_kategori.php?id=<?= (int)$row['id_kategori'] ?>"
                               class="btn btn-info btn-sm">
                                <i class="fas fa-edit"></i> Edit
                            </a>

                            <a href="hapus_pelanggaran_kategori.php?id=<?= (int)$row['id_kategori'] ?>"
                               class="btn btn-danger btn-sm"
                               onclick="return confirm('Yakin ingin menghapus kategori ini?')">
                                <i class="fas fa-trash"></i> Hapus
                            </a>

                        </td>

                    </tr>

                    <?php } ?>

                </tbody>

            </table>

        </div>

    </div>

    <div class="footer">
        Sistem Pelanggaran Siswa &copy; <?= date('Y') ?>
    </div>

</main>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

<script src="https://cdn.datatables.net/1.13.8/js/jquery.dataTables.min.js"></script>

<script src="https://cdn.datatables.net/1.13.8/js/dataTables.bootstrap4.min.js"></script>

<script>
$(document).ready(function () {

    $('#tabelKategori').DataTable({

        pageLength: 10,

        lengthMenu: [
            [5, 10, 25, 50, -1],
            [5, 10, 25, 50, 'Semua']
        ],

        searching: true,
        ordering: true,
        paging: true,
        info: true,
        autoWidth: false,

        order: [[1, 'asc']],

        columnDefs: [{
            targets: 4,
            orderable: false,
            searchable: false
        }],

        language: {
            search: 'Cari:',
            searchPlaceholder: 'Cari kategori...',
            lengthMenu: 'Tampilkan _MENU_ data',
            info: 'Menampilkan _START_ sampai _END_ dari _TOTAL_ data',
            infoEmpty: 'Tidak ada data',
            infoFiltered: '(difilter dari _MAX_ total data)',
            zeroRecords: 'Data tidak ditemukan',
            emptyTable: 'Belum ada kategori pelanggaran',

            paginate: {
                first: 'Pertama',
                last: 'Terakhir',
                next: 'Berikutnya',
                previous: 'Sebelumnya'
            }
        }

    });

});
</script>

</body>
</html>
